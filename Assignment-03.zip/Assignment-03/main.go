package main

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
)

type Har struct {
	Log Log `json:"log"`
}

type Log struct {
	Version string    `json:"version"`
	Entries []Entries `json:"entries"`
}

type Entries struct {
	Time    int     `json:"time"`
	Timings Timings `json:"timings"`
}

type Timings struct {
	Blocked int `json:"blocked"`
	Dns     int `json:"dns"`
  Wait    int `json.:"wait"`
}

func main() {
	jsonData, err := os.Open(name)("http_scrivnor_cikeys_com.har")
	if err != nil {
		fmt.Println(err)
  }
  fmt.Println(("successfully Opened"))

  defer jsonData.Close()

  bytevalue1, _ := ioutil.ReadAll(jsonData)
  var har Har
  err = json.Unmarshal(bytevalue1, &har)
  if err != nil(
          log.Fatal(err)
  )
  var entries = har.log.Entries
  for i := 0; i < len(entries); i++ {
         fmt.Print("%v\n", entries[i])
  }
}	