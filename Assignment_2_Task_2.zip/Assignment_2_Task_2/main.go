package main  


// Import
import (
	"fmt"
	"io"
	"os"
)

// Path to the input file
const filepath string = "input.txt"
// Printing size as Output
const size1 int = 512


// Example1 function will read a input file byte. Converting read byte value 
// to decimal equivalent and store it into byte array.
func Example1( ) {

    // Opening file for reading
	f, err := os.Open(filepath)
	// Checking for error
    if err != nil {
        // File handle is not valid
    	if f != nil {
    	    // Close the file
    		f.Close()
    	}
    	// Print out the error message
    	fmt.Println(err)
    	return
    }
    
    // Define array a1 
    a1 := make([]int ,  size1)
    // Define array b2
    b2 := make([]byte,    1)
    // Initial running counter. 
    count := 0
    // Counter that increments every time byte is read. Running total bytes read
    total := 0
    
    // Continue reading until it reach end of file
    for {
       // Read single byte from input file and store it into array b2
       n, err := io.ReadAtLeast(f, b2, 1)
       // Checking for any errors
       if err != nil {
       	   //fmt.Println(err)
       	   // Checking for End-Of-File is reach
           if err == io.EOF {
       	      break; // break out of loop
            }
       }
       // Check atleast one byte is read from a file
       if n != 0 {
       		// Converting byte to decimal equivalent
        	a1[count] = int(b2[0])
        	// Increment counters
        	count++
        	// Also add to running total counter
        	total++
        	// Check if enough bytes equal to the chunks size is read
        	if count == size1 {
        	    // if so, then print out the entire chunk
        		fmt.Println(a1[0:size1])
        		fmt.Println()
        		// Set counter to the zero
        		count = 0
        	}
       }
    }
    // Checking for the remainimg bytes
    if count != 0 {
    	// Print the remaing bytes left
      	fmt.Println(a1[0:count])
      	fmt.Println()
    }

	// Close file 
    f.Close()
    a1 = nil
    b2 = nil
}

func Example2( ) {

	// Open file for reading
	f, err := os.Open(filepath)
	// Check for error
    if err != nil {
        // File handle is not valid
    	if f != nil {
    	    // Closing the file
    		f.Close()
    	}
    	// Print out the error message
    	fmt.Println(err)
    	return
    }
    
    // Get file information
    fs, err := f.Stat()
    // Check for error
    if err != nil {
        // File handle is not valid
    	if fs != nil {
    	    // Closing the file
    		f.Close()
    	}
    	// Print out the error message
    	fmt.Println(err)
    	return
    }
    
    // Get file size
    var size int64 = fs.Size()    
    //Break it down into number of 512 chunks
    var chunks1 int64 = size / int64(size1)
    // Remaining chunks if any
    var chunks2 int64 = size - (chunks1 * int64(size1))
    
    // Define array b2 of size chunks i.e. 512, to store byte decimal value
    b2 := make([]byte ,  size)
    
    // Loop through number of chunks and print 
    for i := int64(0); i < chunks1; i++ {
    	// Read 512 bytes chunk into byte array
    	n, err := io.ReadAtLeast(f, b2, size1)
    	// Check for the error
    	if err != nil {
    		f.Close()
    		fmt.Printf("Error reading file\n")
    	} 
    	// Print out 512 chunks
    	if n != 0 {
    		fmt.Println(b2[0:n])
    		fmt.Println();
    	}
    }
    // Checking for remaining 
    if chunks2 != 0 {
     	// Read remaining last chunks from file
    	n, err := io.ReadAtLeast(f, b2, int(chunks2))
    	// Check for any errors
    	if err != nil {
    		f.Close()
    		fmt.Printf("Error reading remaining chunks from file\n")
    	} 
    	// Print out last remaining chunks
    	if n != 0 {
    		fmt.Println(b2[0:n])
    		fmt.Println();
    	}
    }
    
    // Close file handle
    f.Close()
    
}


func main() {



   
    Example1()
}